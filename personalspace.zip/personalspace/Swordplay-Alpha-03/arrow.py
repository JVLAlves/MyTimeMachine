side = {

"up": {
  "opposite": "down",
  "counter": ["left", "right"]
},

"down": {
  "opposite": "up",
  "counter": ["left", "right"]
},

"left": {
  "opposite": "right",
  "counter": ["down","up"]
},

"right": {
  "opposite": "left",
  "counter": ["down", "up"]
}

}