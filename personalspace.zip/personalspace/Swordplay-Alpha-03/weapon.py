bag = {
"katana": ["up", "left", "down", "right", "left", "right"],
"axe": ["up", "left", "down", "right","down"],
"spear" : ["up", "left", "down", "right","up"],
"broken sword": ["up", "left", "down", "right"]

}

book = {
"katana": 10,
"axe": 15,
"spear" : 8,
"broken sword": 3

}