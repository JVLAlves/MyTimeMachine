import weapon as w
troops = { 
 "Samurai":{ 
   "Weapon": "Katana",
   "Wheelspin": w.bag["katana"],
   "Damage": w.book["katana"],
   "Health": 125,
   "Lvl.": 9
},
 "Rusty Knight": {
   "Weapon": "Broken Sword",
   "Wheelspin": w.bag["broken sword"],
   "Damage": w.book["broken sword"],
   "Health": 50,
   "Lvl.": 1
},
 "Dwarf": {
   "Weapon": "Axe",
   "Wheelspin": w.bag["axe"],
   "Damage": w.book["axe"],
   "Health": 150,
   "Lvl.": 10
},
 "Lancer": {
   "Weapon": "Spear",
   "Wheelspin": w.bag["spear"],
   "Damage": w.book["spear"],
   "Health": 100,
   "Lvl.": 8
 }
}