quotes = {

  "english": {
    "Intro": "Welcome to [[magenta]]'Swordplay'![[white]]",
    "Explanation": "This is a game of chooses and a certain luck. Our main language is english, so the game will run in this tongue - Get used to it *Laughs*",
    "Weapon Tutorial": "When you enter in a fight you will have to choose a weapon, each weapon has its own stronger and weaker points, but actually that is not as important as the directions you choose.",
    "Directions Tutorial": "Weapon chosen, now you should choose direction to attack. The possible chooses of direction are the known Cardinal ones (up, down, left and right), at least for games. it is important to mention that [[red]]all diretions must be written in english.[[white]]"
  },

  "portuguese": {
    "Intro": "Bem-Vindo ao [[magenta]]'Swordplay'![[white]]",
    "Explanation": "Este é um jogo the escolhas e um tanto de sorte. Nosso idioma principal é o inglês, logo o jogo ira rodar nessa lingua - Acostume-se *Risos*",
    "Weapon Tutorial": "Quando você entrar em combate you terá de escolher uma arma, cada arma tem seus pontos fortes e fracos, mas na verdade isso não é tão importante quantos as direções.",
    "Directions Tutorial": "Arma escolhida, agora você deverá escolher um direção para atacar. As possiveis escolhas de direção são as conhecidas Cardeas (para cima, para baixo, esquerda e direita), ao menos para jogos. É importante mencionar que [[red]]todas as direções devem obrigatóriamente ser escritas em inglês.[[white]]"
  },

  "japanese": {
   "Intro": "[[magenta]]「ソードプレイ」[[white]]へようこそ",
    "Explanation": "これは選択のゲームであり、少し運がいいです。私たちの主な言語は英語なので、ゲームはその言語で実行されます-それに慣れてください*笑い*",
    "Weapon Tutorial": "戦闘に入るときは、武器を選択する必要があります。各武器には長所と短所がありますが、実際には方向ほど重要ではありません",
    "Directions Tutorial": "選択した武器、攻撃する方向を選択する必要があります。方向の可能な選択は、少なくともゲームでは、既知のCardeas（上、下、左、右）です。[[red]]すべての指示は英語で書かれなければならないことに言及することが重要です。[[white]]"
  },
  

  
}