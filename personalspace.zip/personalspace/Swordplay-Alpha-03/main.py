#Modules
import random
import weapon as w 
import time
import asthetics as a
import Enemy as en
import arrow as ar
from instructions import *

#functions
def Damage(n):
 wl = ["katana", "axe", "spear", "broken sword"]
 if n in wl :
   d = w.book[n]
 return d
def Enemy():
 wl = random.choice(["Samurai","Rusty Knight", "Lancer", "Dwarf"])
 return wl 

def EnemyWeapon(eww):
 c = en.troops[eww]["Weapon"]
 return c

def EnemyDamage(eww):
 d = en.troops[eww]["Damage"]
 return d

def EnemyHealth(eww):
  h = en.troops[eww]["Health"]
  return h

def EnemyChances(eww):
  ch = en.troops[eww]["Wheelspin"]
  return ch

def Enemylevel(eww):
  l = en.troops[eww]["Lvl."]
  return l

#introductions
print("[English, Portuguese, Japanese]")
tongue = input("Choose a language: ").lower()
print()
print(a.colorText(quotes[tongue]["Intro"]))
time.sleep(3)
print()
print(a.colorText(quotes[tongue]["Explanation"]))
time.sleep(8)
print()
print(a.colorText(quotes[tongue]["Weapon Tutorial"]))
time.sleep(12)
print()
print(a.colorText(quotes[tongue]["Directions Tutorial"]))
time.sleep(12)
print()

#Preparing
wl = ["Katana", "Axe", "Spear", "Broken Sword"]
#Escolha de arma
print(a.colorText("You entered in a fight... [[red]]Choose a Weapon.[[white]]"))
time.sleep(1.5)
print()
print(a.colorText('[[green]]" '))
for weapon in wl:
 print(a.colorText(" [[green]]{}".format(weapon)))
 time.sleep(0.3)
 print()
 time.sleep(1)
print(a.colorText('             "[[white]]'))

 
print()

n = str(input(a.colorText("[[yellow]]Weapon:[[white]] "))).lower()
an = a.colorText("[[yellow]]{}[[white]]".format(n))
time.sleep(1.5)
print()
print(a.colorText("[[white]]You choose {} as your weapon.".format(an)))
time.sleep(2.3)

# Heroi Status
hh = 100
hd = Damage(n)

# Inimigo Status
print("Now we are setting you enemy status...")
time.sleep(3)
e = Enemy()
ed = EnemyDamage(e)
eh = EnemyHealth(e)
ewn = EnemyWeapon(e)
el = Enemylevel(e)
ew = w.bag[EnemyWeapon(e).lower()]
#Batalha
print(a.colorText("You're gonna face the [[yellow]]{0}[[white]], a fighter from Lvl. [[magenta]]{1}[[white]].".format(e,el)))
time.sleep(4)
print(a.colorText("The weapon you are fight against is [[red]]{}[[white]]".format(ewn)))
time.sleep(4)
print()
print("Ready for the Battle?")
timer = 5
while timer > -1 :
  print(timer)
  timer -= 1
  time.sleep(1)
print()
print(a.colorText("[[green]]Go![[white]]"))
print()

#game start Function
def Battle(eh,ed,hh,ew,hd):
 while eh > 0: 
   c = random.choice(ew)
   direction = input("Diretion: ").lower()
   time.sleep(1)

   if c == ar.side[direction]["opposite"]:
     print(a.colorText("[[red]]Ouch![[white]]"))
     time.sleep(0.5)
     hh = hh - ed
     print()
     print(a.colorText("Enemy was attacking from [[blue]]{}[[white]]".format(c)))
     time.sleep(0.5)
   elif c in ar.side[direction]["counter"]:
     print(a.colorText("[[green]]HIT![[white]]"))
     time.sleep(0.5)
     eh = eh - hd
     print()
     print(a.colorText("Enemy was attacking from [[blue]]{}[[white]]".format(c)))
     time.sleep(0.5)
   elif c == direction:
     print(a.colorText("[[yellow]]Draw![[white]]"))
     time.sleep(0.3)
     print()
     print("FAST! It's time for you to counter-attack. Choose another direction.")
     print()
     time.sleep(1)
     direction = input().lower()
     time.sleep(1)
     if c == ar.side[direction]["opposite"]:
       print(a.colorText("[[red]]Ouch![[white]]"))
       hh = hh - (ed//2)
       print()
       time.sleep(0.5)
       print(a.colorText("Enemy was attacking from [[blue]]{}[[white]], but it scraped.".format(c)))
       time.sleep(0.5)
     elif c in ar.side[direction]["counter"]:
       print(a.colorText("[[cyan]]HIT, But it scraped.[[white]]"))
       time.sleep(0.5)
       eh = eh - (hd//2)
       print()
       print(a.colorText("Enemy was trying attacking from [[blue]]{}[[white]], [[magenta]]but fails[[white]].".format(c)))
       time.sleep(0.5)
       


 
 
   if hh <= 0: 
     print(a.colorText("[[red]] You lose![[white]]"))
     time.sleep(0.5)
     print()
     print("Your HP:", hh)
     time.sleep(0.3)
     print("Enemy's HP:", eh)
     break
   if eh <= 0: 
     print(a.colorText("[[green]] You Won![[white]]"))
     time.sleep(0.5)
     print()
     print("Your HP:", hh)
     time.sleep(0.3)
     print("Enemy's HP:", eh)
     break
   print()
   print("Your HP:", hh)
   print("Enemy's HP:", eh)
   time.sleep(2.5)
   print()
 print()
 print("End!")
 print("Your Weapon was:", n)
 print("Enemy's Weapon was:", ewn)


#Start The Game

Battle(eh,ed,hh,ew,hd)
print()


