# Personal
My personal repository for me to not mess up things anymore.
