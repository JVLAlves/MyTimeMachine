

var weaponbag = {
    "katana": ["up", "left", "down", "right", "left", "right"],
    "axe": ["up", "left", "down", "right","down"],
    "spear" : ["up", "left", "down", "right","up"],
    "brokenSword": ["up", "left", "down", "right"]
    
};

var weapondamage = {
    "katana": 10,
    "axe": 15,
    "spear" : 8,
    "brokenSword": 3
};


var samurai = { 
    "weapon": "Katana",
   "wheelSpin": weaponbag["katana"] ,
   "damage": weapondamage["katana"],
   "health": 125,
   "level": 9
};

var rustyKnight = {
    "weapon": "Broken Sword",
   "wheelSpin": weaponbag["brokenSword"],
   "damage": weapondamage["brokenSword"],
   "health": 50,
   "level": 1
};

var dwarf =  {
    "weapon": "Axe",
   "wheelSpin": weaponbag["axe"],
   "damage": weapondamage["axe"],
   "health": 150,
   "level": 10
};
var lancer = {
    "weapon": "Spear",
   "wheelSpin": weaponbag["spear"],
   "damage": weapondamage["spear"],
   "health": 100,
   "level": 8
};

var troops = [samurai, rustyKnight, dwarf, lancer]

function startGame(){ 
    var button = document.getElementById("button-addon2");
    button.style.display = "none";

    var title = document.createElement("h1")
    title.setAttribute("id", "title")
    title.innerHTML = "Welcome to Swordplay Online!"
    document.getElementById("header").appendChild(title);

    var subtitle = document.createElement("small")
    subtitle.setAttribute("id", "subtitle")
    subtitle.innerHTML = '(Even not being so "online")'
    document.getElementById("header").appendChild(subtitle)
    
    var btn = document.createElement("button");
    document.getElementById("btn1").appendChild(btn)
    btn.setAttribute("class", "btn btn-success")
    btn.setAttribute("type", "button")
    btn.setAttribute("id", "button")
    btn.setAttribute("onclick","")
    btn.innerHTML = "Play"
}