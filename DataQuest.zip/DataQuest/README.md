# Dinamize-Inventory
Imagine um excelente README aqui.

## TODO
*Netflix Noises*

 * Escrever README
 * Criar Globals (Se necessário)
 * Aplicar metrics (Se necessário)
 * Quebrar e aprimorar funções
 * Criar Configs
 * Aprimorar Logs
