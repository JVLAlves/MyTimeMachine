package LinearSys

import (
	"context"
	"fmt"
	"math"

	"github.com/fatih/color"
	"github.com/rodaine/table"
)

type LinearSystemT struct {
	Numbers [][]float64
	Seeds   []float64
	Errmax  float64
}

var (
	column1 []float64 = []float64{20, 1, 1, 1, 33}
	column2 []float64 = []float64{1, 10, 2, 4, 38.4}
	column3 []float64 = []float64{1, 2, 10, 1, 43.5}
	column4 []float64 = []float64{2, 4, 1, 20, 45.6}
)

func main() {
	counter := make(chan int)
	result := make(chan []float64)
	Ln := NewLinearSystem()
	ctx, cancel := context.WithCancel(context.Background())
	Ln.Numbers = [][]float64{column1, column2, column3, column4}
	Ln.Seeds = []float64{1.65, 3.84, 4.35, 2.28}
	Ln.Errmax = math.Pow10(-5)

	go Ln.GaussSeidel(counter, result)
	go Timeout(10, counter, result, ctx, cancel)

	for {
		select {
		case <-ctx.Done():
			fmt.Println("timeout")
			return
		case v := <-result:
			fmt.Println()
			fmt.Println(v)
			Showresults(v)
			Ln.Proving(v)
			return
		}

	}
}
func NewLinearSystem() *LinearSystemT {
	return &LinearSystemT{}
}

func Timeout(n int, c <-chan int, ch <-chan []float64, ctx context.Context, cancel context.CancelFunc) {

	for {

		select {
		case v := <-c:
			if v > (n + 1) {
				cancel()
			}
		default:
			continue
		}

	}
}

func (ls LinearSystemT) GaussSeidel(c chan<- int, ch chan<- []float64) {
	var (
		x    float64 = ls.Seeds[0]
		legx float64
		y    float64 = ls.Seeds[1]
		legy float64
		z    float64 = ls.Seeds[2]
		legz float64
		a    float64 = ls.Seeds[3]
		lega float64

		Imagem []float64

		errx float64
		erry float64
		errz float64
		erra float64
	)

	//Define a formatação da tabela que será criada futuramente
	headerFmt := color.New(color.FgGreen, color.Underline).SprintfFunc()
	columnFmt := color.New(color.FgYellow).SprintfFunc()

	//Cria tabela com os Cabeçalhos "Iterações", "x", "f(x)"
	tbl := table.New("Iterations", "(x1)", "(x2)", "(x3)", "(x4)", "ErroX1", "ErroX2", "ErroX3", "ErroX4")

	//Implementação da formatação
	tbl.WithHeaderFormatter(headerFmt).WithFirstColumnFormatter(columnFmt)

	tbl.AddRow(-1, x, y, z, a, "null", "null", "null", "null")

	i := 0
	for {
		fmt.Println("\n", "Iteration ", i, "\n")
		for in, v := range ls.Numbers {

			switch in {

			case 0:
				//Primeira equation 10 2 1 7
				legx = x
				//		b             num2   x2    num3   x3    num4  x4     num1
				x = (v[(len(v)-1)] - (v[1] * y) - (v[2] * z) - (v[3] * a)) / v[0]
				fmt.Printf("(x1)\t%.10f = (%.10f - (%.10f * %.10f) - (%.10f * %.10f) - (%.10f * %.10f))/%.10f\n", x, v[(len(v)-1)], v[1], y, v[2], z, v[3], a, v[0])

			case 1:
				//Segunda equaçao 1 5 1 -8
				legy = y
				//		b             num1   x1    num3   x3    num4  x4     num2
				y = (v[(len(v)-1)] - (v[0] * x) - (v[2] * z) - (v[3] * a)) / v[1]
				fmt.Printf("(x2)\t%.10f = (%.10f - (%.10f * %.10f) - (%.10f * %.10f) - (%.10f * %.10f))/%.10f\n", y, v[(len(v)-1)], v[0], x, v[2], z, v[3], a, v[1])
			case 2:
				//Terceira equation 2 3 10 6
				legz = z
				//		b             num1   x1    num2   x2    num4  x4     num3
				z = (v[(len(v)-1)] - (v[0] * x) - (v[1] * y) - (v[3] * a)) / v[2]
				fmt.Printf("(x3)\t%.10f = (%.10f - (%.10f * %.10f) - (%.10f * %.10f) - (%.10f * %.10f))/%.10f\n ", z, v[(len(v)-1)], v[0], x, v[1], y, v[3], a, v[2])
			case 3:
				//Quarta equation
				lega = a
				//		b             num1   x1    num2   x2    num3  x3     num4
				a = (v[(len(v)-1)] - (v[0] * x) - (v[1] * y) - (v[2] * z)) / v[3]
				fmt.Printf("(x4)\t%.10f = (%.10f - (%.10f * %.10f) - (%.10f * %.10f) - (%.10f * %.10f))/%.10f\n ", a, v[(len(v)-1)], v[0], x, v[1], y, v[2], z, v[3])
			}

		}

		checkx := false
		checky := false
		checkz := false
		checka := false

		errx = math.Abs((x - legx))
		if errx < ls.Errmax {
			checkx = true
		}
		fmt.Printf("\n(ErroX1)\t%.10f = |%.10f - %.10f|\t%v\n\n", errx, x, legx, checkx)
		erry = math.Abs((y - legy))
		if erry < ls.Errmax {
			checky = true
		}
		fmt.Printf("\n(ErroX2)\t%.10f = |%.10f - %.10f|\t%v\n\n", erry, y, legy, checky)
		errz = math.Abs((z - legz))
		if errz < ls.Errmax {
			checkz = true
		}
		fmt.Printf("\n(ErroX3)\t%.10f = |%.10f - %.10f|\t%v\n\n", errz, z, legz, checkz)
		erra = math.Abs((a - lega))
		if erra < ls.Errmax {
			checka = true
		}
		fmt.Printf("\n(ErroX4)\t%.10f = |%.10f - %.10f|\t%v\n\n", erra, a, lega, checka)

		tbl.AddRow(i, fmt.Sprintf("%.10f", x), fmt.Sprintf("%.10f", y), fmt.Sprintf("%.10f", z), fmt.Sprintf("%.10f", a), errx, erry, errz, erra)

		if errx < ls.Errmax && erry < ls.Errmax && errz < ls.Errmax && erra < ls.Errmax {
			Imagem = append(Imagem, x, y, z, a)
			ch <- Imagem
			tbl.Print()
		}
		i++
		c <- i
	}
}
func (line LinearSystemT) Proving(conv []float64) {
	var (
		x     float64 = conv[0]
		y     float64 = conv[1]
		z     float64 = conv[2]
		a     float64 = conv[3]
		respx float64
		respy float64
		respz float64
		respa float64
	)

	for in, v := range line.Numbers {

		switch in {

		case 0:
			respx = ((v[0] * x) + (v[1] * y) + (v[2] * z) + (v[3] * a))
			fmt.Printf("(linha 1)\t%.10f = ((%.10f * %.10f) + (%.10f * %.10f) + (%.10f * %.10f) + (%.10f * %.10f))\n", respx, v[0], x, v[1], y, v[2], z, v[3], a)

		case 1:
			respy = ((v[0] * x) + (v[1] * y) + (v[2] * z) + (v[3] * a))
			fmt.Printf("(linha 2)\t%.10f = ((%.10f * %.10f) + (%.10f * %.10f) + (%.10f * %.10f) + (%.10f * %.10f))\n", respy, v[0], x, v[1], y, v[2], z, v[3], a)
		case 2:
			respz = ((v[0] * x) + (v[1] * y) + (v[2] * z) + (v[3] * a))
			fmt.Printf("(linha 3)\t%.10f = ((%.10f * %.10f) + (%.10f * %.10f) + (%.10f * %.10f) + (%.10f * %.10f))\n", respz, v[0], x, v[1], y, v[2], z, v[3], a)
		case 3:
			respa = ((v[0] * x) + (v[1] * y) + (v[2] * z) + (v[3] * a))
			fmt.Printf("(linha 4)\t%.10f = ((%.10f * %.10f) + (%.10f * %.10f) + (%.10f * %.10f) + (%.10f * %.10f))\n", respa, v[0], x, v[1], y, v[2], z, v[3], a)
		}

	}
}

func Showresults(results []float64) [4]float64 {
	var vreal [4]float64
	for in, v := range results {

		r := math.Round(v)
		vreal[in] = r

	}

	fmt.Printf("\nConvergindo para x = %.10f\n", vreal)
	fmt.Println()
	return vreal
}

func (ls LinearSystemT) GaussJacobi(c chan<- int, ch chan<- []float64) {
	var x float64
	var y float64
	var z float64

	var Imagem []float64

	var errx float64
	var erry float64
	var errz float64

	i := 0
	for {
		fmt.Println("\n", "Iteration ", i, "\n")
		fmt.Println(ls.Seeds, "\n")
		for in, v := range ls.Numbers {

			switch in {

			case 0:
				//Primeira equation 10 2 1 7
				x = (v[(len(v)-1)] - (v[1] * ls.Seeds[1]) - (v[2] * ls.Seeds[2])) / v[0]
				fmt.Printf("(x)\t%.10f = (%.10f - (%.10f * %.10f) - (%.10f * %.10f))/%.10f\n", x, v[(len(v)-1)], v[1], ls.Seeds[1], v[2], ls.Seeds[2], v[0])

			case 1:
				//Segunda equaçao 1 5 1 -8
				y = (v[(len(v)-1)] - (v[0] * ls.Seeds[0]) - (v[2] * ls.Seeds[2])) / v[1]
				fmt.Printf("(y)\t%.10f = (%.10f - (%.10f * %.10f) - (%.10f * %.10f))/%.10f\n", y, v[(len(v)-1)], v[0], ls.Seeds[0], v[2], ls.Seeds[2], v[1])
			case 2:
				//Terceira equation 2 3 10 6
				z = (v[(len(v)-1)] - (v[0] * ls.Seeds[0]) - (v[1] * ls.Seeds[1])) / v[2]
				fmt.Printf("(z)\t%.10f = (%.10f - (%.10f * %.10f) - (%.10f * %.10f))/%.10f\n ", z, v[(len(v)-1)], v[0], ls.Seeds[0], v[1], ls.Seeds[1], v[2])
			}

		}
		errx = math.Abs((x - ls.Seeds[0]))
		if errx < ls.Errmax {

		}
		fmt.Printf("\n(errx)\t%.10f = |%.10f - %.10f|\n", errx, x, ls.Seeds[0])
		erry = math.Abs((y - ls.Seeds[1]))
		fmt.Printf("\n(erry)\t%.10f = |%.10f - %.10f|\n", erry, y, ls.Seeds[1])
		errz = math.Abs((z - ls.Seeds[2]))
		fmt.Printf("\n(errz)\t%.10f = |%.10f - %.10f|\n\n", errz, z, ls.Seeds[2])
		if errx < ls.Errmax && erry < ls.Errmax && errz < ls.Errmax {
			Imagem = append(Imagem, x, y, z)
			ch <- Imagem
		}

		ls.Seeds = []float64{x, y, z}
		i++
		c <- i
	}
}
