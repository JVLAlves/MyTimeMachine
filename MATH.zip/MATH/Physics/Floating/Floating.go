package Bouyancy

import (
	"fmt"
	"math"

	"github.com/fatih/color"
	"github.com/rodaine/table"
)

type BouceI interface {
	Equilibrium() BouyancyResults
}
type Bouyancy struct {
	a      float64
	b      float64
	y      float64
	i      func(float64, float64) float64
	BM     func(float64, float64) float64
	CGM    func(float64, float64, float64, float64) float64
	P      float64
	W      float64
	x      float64
	degree float64
}

type BouyancyResults struct {
	a          float64
	b          float64
	y          float64
	i          float64
	V          float64
	BM         float64
	CGM        float64
	BCG        float64
	P          float64
	W          float64
	x          float64
	degree     float64
	estability string
}

var BM func(float64, float64) float64
var CGM func(float64, float64, float64, float64) float64
var i func(float64, float64) float64

func (b Bouyancy) Equilibrium() (BOR BouyancyResults) {
	I := b.i(b.a, b.b)
	V := (b.W * 9.8) / b.y
	BM := b.BM(I, V)
	CGM := b.CGM((b.P * 9.8), b.x, (b.W * 9.8), b.degree)
	BCG := BM - CGM
	BOR = BouyancyResults{}

	BOR.a = b.a
	BOR.b = b.b
	BOR.y = b.y
	BOR.i = I
	BOR.V = V
	BOR.BM = BM
	BOR.CGM = CGM
	BOR.P = (b.P * 9.8)
	BOR.x = b.x
	BOR.W = (b.W * 9.8)
	BOR.degree = b.degree
	BOR.BCG = BCG

	switch {
	case BM > BCG:
		BOR.estability = "ESTÁVEL"
	case BM < BCG:
		BOR.estability = "INSTÁVEL"
	case BM == BCG:
		BOR.estability = "NEUTRO"
	}

	fmt.Println("DONE AND DUSTED")

	return BOR
}

func Showresults(b BouceI) {

	BOR := b.Equilibrium()

	//Define a formatação da tabela que será criada futuramente
	headerFmt := color.New(color.FgGreen, color.Underline).SprintfFunc()
	columnFmt := color.New(color.FgYellow).SprintfFunc()

	//Cria tabela com os Cabeçalhos "Iterações", "x", "f(x)"
	tbl := table.New("Field", "Value")

	//Implementação da formatação
	tbl.WithHeaderFormatter(headerFmt).WithFirstColumnFormatter(columnFmt)

	tbl.AddRow("MEDIDA A", BOR.a)
	tbl.AddRow("MEDIDA B", BOR.b)
	tbl.AddRow("PESO DO CORPO", BOR.W)
	tbl.AddRow("PESO DA CARGA", BOR.P)
	tbl.AddRow("DESLOCAMENTO DA CARGA", BOR.x)
	tbl.AddRow("INCLINAÇÃO (em graus)", BOR.degree)
	tbl.AddRow("PESO ESPECIFICO DO LIQUIDO", BOR.y)
	tbl.AddRow("VOLUME SUBMERSO", BOR.V)
	tbl.AddRow("MOMENTO DE INÉRCIA", BOR.i)
	tbl.AddRow("BM", BOR.BM)
	tbl.AddRow("BCG", BOR.BCG)
	tbl.AddRow("CGM", BOR.CGM)
	tbl.AddRow("ESTABILIDADE", BOR.estability)

	tbl.Print()

}
func main() {

	i = func(a float64, b float64) float64 { return (a * (math.Pow(b, 3))) / 12 }
	BM = func(i float64, V float64) float64 { return i / V }
	CGM = func(p float64, x float64, W float64, degree float64) float64 {
		Inrad := (math.Pi / 180) * degree
		return (p * x) / (W * (math.Tan(Inrad)))

	}

	eq := Bouyancy{

		a:      70,
		b:      9,
		W:      1767000,
		P:      17000,
		x:      7,
		degree: 3,
		y:      10250,
		i:      i,
		BM:     BM,
		CGM:    CGM,
	}

	Showresults(eq)
}
